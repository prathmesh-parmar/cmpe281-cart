var server_ip_pc="localhost";
var server_port_pc="8000";
module.exports.server_ip_pc=server_ip_pc;
module.exports.server_port_pc=server_port_pc;
