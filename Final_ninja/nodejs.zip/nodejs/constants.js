var limitvalue=2; //for home page to get top products based in avg ratings
var ip="52.14.77.163";
var port=8000;
module.exports.limitvalue=limitvalue;
module.exports.ip=ip;
module.exports.port=port;
